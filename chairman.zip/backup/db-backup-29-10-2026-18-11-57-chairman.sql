

CREATE TABLE `attlog` (
  `empolyeeID` varchar(50) NOT NULL,
  `authdatetime` text NOT NULL,
  `authdate` text NOT NULL,
  `authtime` text NOT NULL,
  `direction` text NOT NULL,
  `devicename` text NOT NULL,
  `devicesn` text NOT NULL,
  `personname` text NOT NULL,
  `carno` text NOT NULL,
  `adddatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO attlog VALUES("4","2022-12-04T18:05:11","2022-12-04","18:05:11","IN","attendace","DS-K1A8503MF-B20191120V010203ENE12098421","Noman","","2022-12-04 21:21:16");
INSERT INTO attlog VALUES("4","2022-12-04T19:16:23","2022-12-04","19:16:23","IN","attendace","DS-K1A8503MF-B20191120V010203ENE12098421","Noman","","2022-12-04 21:21:16");
INSERT INTO attlog VALUES("4","2022-12-04T19:16:25","2022-12-04","19:16:25","IN","attendace","DS-K1A8503MF-B20191120V010203ENE12098421","Noman","","2022-12-04 21:21:16");
INSERT INTO attlog VALUES("5","2022-12-04T19:54:07","2022-12-04","19:54:07","IN","attendace","DS-K1A8503MF-B20191120V010203ENE12098421","Demo","","2022-12-04 21:21:16");
INSERT INTO attlog VALUES("5","2022-12-14T14:27:38","2022-12-14","14:27:38","IN","attendace","DS-K1A8503MF-B20191120V010203ENE12098421","Demo","","2022-12-14 14:27:41");





CREATE TABLE `brands` (
  `brand_id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_name` varchar(255) NOT NULL,
  `brand_active` int(11) NOT NULL DEFAULT 0,
  `brand_status` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`brand_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO brands VALUES("1","poly bags","0","1");
INSERT INTO brands VALUES("10","china","0","1");





CREATE TABLE `brokers` (
  `broker_id` int(255) NOT NULL AUTO_INCREMENT,
  `broker_name` text NOT NULL,
  `broker_phone` text NOT NULL,
  `broker_email` text NOT NULL,
  `broker_address` text NOT NULL,
  `broker_status` int(11) NOT NULL,
  `adddatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`broker_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;






CREATE TABLE `budget` (
  `budget_id` int(11) NOT NULL AUTO_INCREMENT,
  `budget_name` text NOT NULL,
  `budget_amount` double NOT NULL,
  `budget_type` varchar(300) NOT NULL,
  `voucher_id` int(11) DEFAULT NULL,
  `voucher_type` int(11) DEFAULT NULL,
  `budget_date` date NOT NULL,
  `budget_add_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`budget_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO budget VALUES("1","expense added to shop","5000","expense","8","1","2021-06-20","2021-06-20 18:35:45");
INSERT INTO budget VALUES("2","expense added to shop","2000","expense","9","1","2021-06-20","2021-06-20 18:39:56");
INSERT INTO budget VALUES("3","expense added to shop","1000","expense","6815","1","2023-09-25","2023-09-25 22:17:47");





CREATE TABLE `budget_category` (
  `budget_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `budget_category_name` text NOT NULL,
  `budget_category_type` varchar(400) NOT NULL,
  `budget_category_add_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`budget_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;






CREATE TABLE `categories` (
  `categories_id` int(11) NOT NULL AUTO_INCREMENT,
  `categories_name` varchar(255) NOT NULL,
  `category_price` varchar(100) NOT NULL DEFAULT '1',
  `category_purchase` varchar(100) NOT NULL,
  `categories_active` int(11) NOT NULL DEFAULT 0,
  `categories_status` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`categories_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO categories VALUES("1","pvc rolls","1","","0","1");
INSERT INTO categories VALUES("2","pvc bags","1","","0","1");
INSERT INTO categories VALUES("3","hanger","1","","0","1");
INSERT INTO categories VALUES("4","imp","8.75","","0","1");
INSERT INTO categories VALUES("5","super cler","9.35","","0","1");
INSERT INTO categories VALUES("6","sada ns","8.75","","0","1");
INSERT INTO categories VALUES("9","ahsan","1","","0","1");
INSERT INTO categories VALUES("14","zipper","1","","0","1");





CREATE TABLE `checks` (
  `check_id` int(11) NOT NULL AUTO_INCREMENT,
  `check_no` varchar(250) DEFAULT NULL,
  `check_bank_name` varchar(250) DEFAULT NULL,
  `check_expiry_date` varchar(100) DEFAULT NULL,
  `check_type` varchar(100) DEFAULT NULL,
  `voucher_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `check_location` text DEFAULT NULL,
  `check_status` int(11) NOT NULL DEFAULT 0,
  `check_amount` varchar(100) DEFAULT NULL,
  `check_timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`check_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO checks VALUES("5","dd no-72551","","","","189","","","0","","2021-09-20 12:45:24");
INSERT INTO checks VALUES("6","c-81946794","","","","190","","","0","","2021-09-20 13:17:54");
INSERT INTO checks VALUES("7","no-10371835","bank al habib limited","","","193","","","0","","2021-09-20 17:00:52");
INSERT INTO checks VALUES("8","dd no 08172559","","","","194","","","0","","2021-09-20 17:57:43");
INSERT INTO checks VALUES("9","","","","","195","","","0","","2021-09-20 18:11:40");
INSERT INTO checks VALUES("10","","","","","196","","","0","","2021-09-21 09:35:23");
INSERT INTO checks VALUES("11","dd no-24576120","","","","197","","","0","","2021-09-21 11:09:39");
INSERT INTO checks VALUES("12","","","","","198","","","0","","2021-09-21 12:02:01");
INSERT INTO checks VALUES("13","","","","","199","","","0","","2021-09-21 12:56:21");
INSERT INTO checks VALUES("14","dd ","","","","203","","","0","","2021-09-22 16:28:58");
INSERT INTO checks VALUES("15","dd no-25350518","hbl","2021-09-23","cross pay order","206","","","0","","2021-09-23 11:23:37");
INSERT INTO checks VALUES("16","c86591574","","2021-09-23","","208","","","0","","2021-09-23 13:40:04");
INSERT INTO checks VALUES("17","dd no-06352921","meezan bank ","2021-09-23","cross pay order","209","","","0","","2021-09-23 14:23:58");
INSERT INTO checks VALUES("18","c-68468455","mezzan bank","2021-09-25","check cross","215","","","0","","2021-09-24 16:15:08");
INSERT INTO checks VALUES("19","06352930","meezan bank ","2021-09-24","cross pay order","218","","","0","","2021-09-24 17:22:16");
INSERT INTO checks VALUES("20","dd no 00738","habib metro bank","","","220","","","0","","2021-09-24 17:45:21");
INSERT INTO checks VALUES("21","no-83589262","meezan bank","2021-10-10","check","224","","","0","","2021-09-25 13:12:32");
INSERT INTO checks VALUES("22","c-72659914","meezan bank ","2021-09-25","","225","","","0","","2021-09-25 17:17:16");
INSERT INTO checks VALUES("23","10371834","bank al habib limited","2021-03-10","check","230","","","0","","2021-09-27 11:55:06");
INSERT INTO checks VALUES("24","86591577","meezan bank ","2021-09-27","check","231","","","0","","2021-09-27 17:09:24");
INSERT INTO checks VALUES("25","89357367","meezan bank ","2021-10-18","check cross","234","","","0","","2021-09-28 15:12:27");
INSERT INTO checks VALUES("26","14906246","habib metropolitan bank ltd","2021-09-28","cross pay order","235","","","0","","2021-09-28 16:49:20");
INSERT INTO checks VALUES("27","24788450","habib bank ","2021-09-29","cross pay order","237","","","0","","2021-09-29 14:23:17");
INSERT INTO checks VALUES("28","89357370","meezan bank ","2021-10-20","check","239","","","0","","2021-09-29 16:09:49");
INSERT INTO checks VALUES("29","02851032","silkbank","2021-09-30","cross pay order","243","","","0","","2021-09-30 11:38:17");
INSERT INTO checks VALUES("30","04868382","the bank of punjab","2021-09-29","cross pay order","245","","","0","","2021-09-30 15:23:19");
INSERT INTO checks VALUES("31","10376528","bank al habib limited","2021-10-01","check cross","246","","","0","","2021-09-30 16:34:45");
INSERT INTO checks VALUES("32","24576130","bank al habib limited","2021-10-01","cross pay order","249","","","0","","2021-10-01 15:38:14");
INSERT INTO checks VALUES("33","04868383","the bank of punjab","2021-09-29","cross pay order","250","","","0","","2021-10-01 16:04:41");
INSERT INTO checks VALUES("34","25350538","hbl","2021-10-02","cross pay order","256","","","0","","2021-10-02 11:58:45");
INSERT INTO checks VALUES("36","7573667","meezan bank","2021-11-17","payorder","0","2","bank locker","0","500000","2021-11-17 03:19:04");
INSERT INTO checks VALUES("37","123","meezan ","2023-09-25","cash ","6812","","","0","","2023-09-25 15:44:47");





CREATE TABLE `company` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `logo` text NOT NULL,
  `address` text DEFAULT NULL,
  `company_phone` varchar(100) NOT NULL,
  `personal_phone` varchar(100) NOT NULL,
  `email` text DEFAULT NULL,
  `s_tax_no` varchar(100) DEFAULT NULL,
  `ntn_no` varchar(100) DEFAULT NULL,
  `cnic_no` varchar(100) DEFAULT NULL,
  `stock_manage` int(11) NOT NULL,
  `sale_interface` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO company VALUES("5","BA traders","1802050328651838e477e47.png","Shop # 621, Near Hamza Kanta, Oil Depot Road Tata Market Faisalabad","123456789,312456789","0412551909","testemail@info.com","32-77-8763-934-54","A322716-3","","1","gui");





CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(2000) NOT NULL,
  `customer_email` varchar(200) NOT NULL,
  `customer_phone` varchar(13) NOT NULL,
  `customer_address` text NOT NULL,
  `customer_strn` varchar(100) DEFAULT NULL,
  `customer_ntn` varchar(100) DEFAULT NULL,
  `customer_province` varchar(100) DEFAULT NULL,
  `customer_cnic` varchar(100) DEFAULT NULL,
  `customer_status` int(255) NOT NULL,
  `customer_type` varchar(250) DEFAULT NULL,
  `customer_limit` varchar(100) NOT NULL DEFAULT '0',
  `customer_add_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO customers VALUES("3","meezan bank (bakarmandi)","","03227711909","","","","","","1","bank","0","2021-06-07 09:45:08");
INSERT INTO customers VALUES("6","Cash in hand","","03227711909","","","","","","1","bank","0","2021-06-07 09:45:08");
INSERT INTO customers VALUES("10","Umer Bahi AT","","0","fsd","3423423434234","42342342","sindh","33100-71942475","1","customer","0","2023-10-01 03:50:20");
INSERT INTO customers VALUES("11","MAGNA TRADING","manga@gmail.com","021-3000000","E-25, GROUND FLOOR, IQBAL CENTRE M. A. JINNAH ROAD KARACHI","32-77-8761-660-49","5368642-7","SINDH","","1","supplier","0","2026-10-27 11:11:18");
INSERT INTO customers VALUES("12","PROCON ENGINEERING PVT LTD","","021-4000000","D 54 TO 57 N W I ZONE PORT QASIM","02-01-8708-018-73","0711733-7","SINDH","","1","customer","0","2026-10-27 11:11:18");
INSERT INTO customers VALUES("13","Muhammad Ahsan","mianbest5570@gmail.com","03067055997","67 jb sadhar","3423423434234","42342342","punjab","33100-71942475","1","supplier","0","2026-10-27 11:14:15");
INSERT INTO customers VALUES("15","test","mianbest5570@gmail.com","03067055997","67 jb sadhars","3423423434234","42342342","punjab","33100-71942475","1","customer","0","2026-10-27 11:20:22");
INSERT INTO customers VALUES("16","Muhammad Ahsan","mianbest5570@gmail.com","435345435","67 jb sadhar","234324","34324234","punjabs","32432323","1","customer","0","2026-10-27 12:26:10");
INSERT INTO customers VALUES("18","SEEM INTERNATIONAL","","","","","","","","1","supplier","0","2026-10-28 16:51:30");
INSERT INTO customers VALUES("19","PRAGO IMPORTS","","","","","","","","1","supplier","0","2026-10-28 16:51:30");
INSERT INTO customers VALUES("20","KHEEWA&SONS","","","","","","","","1","supplier","0","2026-10-28 16:51:30");
INSERT INTO customers VALUES("21","SWAN INTERNATIONAL","","","","","","","","1","supplier","0","2026-10-28 16:51:30");
INSERT INTO customers VALUES("22","FOAM CO","","","","","","","","1","customer","0","2026-10-28 16:51:30");
INSERT INTO customers VALUES("23","MASTER ENTERPRISES","","","","","","","","1","customer","0","2026-10-28 16:51:30");
INSERT INTO customers VALUES("24","ahsan","ahsan@gmail.com","03067055997","","","","","","1","customer","0","2026-10-29 14:09:26");





CREATE TABLE `expenses` (
  `expense_id` int(11) NOT NULL AUTO_INCREMENT,
  `expense_name` varchar(100) DEFAULT NULL,
  `expense_status` int(11) DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`expense_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;






CREATE TABLE `hold_product` (
  `hold_product_id` int(255) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `hold_qty` int(11) NOT NULL,
  `customer_name` varchar(250) NOT NULL,
  `added_by` int(11) NOT NULL,
  `is_deleted` int(1) NOT NULL DEFAULT 0,
  `add_datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`hold_product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;






CREATE TABLE `invoices` (
  `invoice_id` int(55) NOT NULL AUTO_INCREMENT,
  `invoice_date` text NOT NULL DEFAULT current_timestamp(),
  `customer_id` int(55) NOT NULL,
  `party_po` varchar(50) DEFAULT NULL,
  `credit_sale_type` varchar(20) DEFAULT NULL,
  `total_amount` varchar(255) DEFAULT '0',
  `discount` varchar(255) DEFAULT '0',
  `freight` varchar(255) DEFAULT '0',
  `grand_total` int(11) NOT NULL,
  `order_narration` text DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `transaction_id` int(11) DEFAULT NULL,
  `invoice_details` text DEFAULT NULL,
  `add_datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`invoice_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO invoices VALUES("2","2026-10-29","16","34","45days","500000","18","","590000","","1","0","{\"data\":[{\"sr\":0,\"party_po\":\"34\",\"dc_no\":\"1\",\"po_amount\":\"500000\"}]}","2026-10-29 13:40:49");





CREATE TABLE `menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text DEFAULT NULL,
  `page` text DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `icon` text DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `nav_edit` int(11) NOT NULL DEFAULT 0,
  `nav_delete` int(11) NOT NULL DEFAULT 0,
  `nav_add` int(11) NOT NULL DEFAULT 0,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=161 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO menus VALUES("97","accounts","#","0","fa fa-edit","6","1","1","1","2026-10-29 16:54:55");
INSERT INTO menus VALUES("98","customers","customers.php?type=customer","97","fa fa-edit","4","1","1","1","2021-04-13 16:03:33");
INSERT INTO menus VALUES("99","banks","customers.php?type=bank","97","fa fa-edit","2","1","1","1","2021-04-13 16:03:33");
INSERT INTO menus VALUES("100","users","users.php","97","fa fa-edit","3","1","1","1","2021-04-13 16:03:33");
INSERT INTO menus VALUES("101","vouchers","#","0","fa fa-clipboard-list","1","0","0","0","2023-09-28 16:10:32");
INSERT INTO menus VALUES("104","Delivery challan ","#","0","fas fa-cart-plus","4","0","0","0","2026-10-29 17:48:34");
INSERT INTO menus VALUES("105","Cash Sale","cash_sale.php","142","fas fa-cart-plus","9","1","0","1","2026-10-29 17:48:34");
INSERT INTO menus VALUES("106","view sales","view_orders.php","142","fa fa-edit","10","0","0","0","2026-10-29 17:48:34");
INSERT INTO menus VALUES("107","others","#","0","fa fa-edit","8","0","0","0","2026-10-29 16:54:55");
INSERT INTO menus VALUES("108","Add Products","product.php?act=add","107","fa fa-edit","12","1","0","1","2026-10-29 17:48:34");
INSERT INTO menus VALUES("109","view products","product.php?act=list","107","fa fa-edit","13","1","1","1","2021-04-13 16:03:34");
INSERT INTO menus VALUES("110","brands","brands.php","107","fa fa-edit","14","1","1","1","2026-10-29 17:48:34");
INSERT INTO menus VALUES("112","Goods","#","0","fa fa-edit","2","0","0","0","2023-10-09 23:32:57");
INSERT INTO menus VALUES("113","Cash Purchase","cash_purchase.php","112","fa fa-edit","","1","1","1","2021-04-13 18:33:37");
INSERT INTO menus VALUES("114","credit purchase","credit_purchase.php","112","fa fa-edit","","1","1","1","2021-04-13 18:34:31");
INSERT INTO menus VALUES("115","Reports","#","0","fa fa-edit","7","0","0","0","2026-10-29 16:54:55");
INSERT INTO menus VALUES("116","bank ledger","reports.php?type=bank","115","fa fa-edit","","1","1","1","2021-04-14 17:03:11");
INSERT INTO menus VALUES("117","supplier ledger","reports.php?type=supplier","115","fa fa-edit","","1","0","0","2021-04-14 17:03:52");
INSERT INTO menus VALUES("118","customer ledger","reports.php?type=customer ","115","fa-edit","","0","0","0","2021-04-14 17:04:27");
INSERT INTO menus VALUES("119","view purchases","view_purchases.php","112","add_to_queue","","1","1","1","2021-04-15 17:17:07");
INSERT INTO menus VALUES("120","categories","categories.php","107","fa fa-edit","","1","1","1","2026-10-29 17:48:34");
INSERT INTO menus VALUES("121","supplier","customers.php?type=supplier","97","fa fa-edit","","1","1","1","2021-04-17 16:36:01");
INSERT INTO menus VALUES("122","expense ","customers.php?type=expense","97","fa fa-edit","","1","1","1","2021-04-17 16:41:42");
INSERT INTO menus VALUES("123","product purchase report","product_purchase_report.php","115","fa fa-edit","","0","0","0","2021-04-20 14:07:34");
INSERT INTO menus VALUES("125","product sale report","product_sale_report.php","115","fa fa-edit","","0","0","0","2021-04-21 15:48:47");
INSERT INTO menus VALUES("127","expense report","expence_report.php","115","fa fa-edit","","0","0","0","2021-04-21 16:11:51");
INSERT INTO menus VALUES("128","income report","income_report.php","115","fa fa-edit","","0","0","0","2021-04-21 16:12:23");
INSERT INTO menus VALUES("129","profit and loss","profit_loss.php","115","fa fa-edit","","0","0","0","2021-04-21 16:12:38");
INSERT INTO menus VALUES("130","profit summary","profit_summary.php","115","fa fa-edit","","0","0","0","2021-04-21 16:12:58");
INSERT INTO menus VALUES("131","trail balance","trail_balance.php","115","fa fa-edit","6","0","0","0","2026-10-29 17:48:34");
INSERT INTO menus VALUES("132","New DC","credit_sale.php?credit_type=30days","104","add_to_queue","","1","0","1","2026-10-29 17:48:34");
INSERT INTO menus VALUES("133","expense type","expense_type.php","107","local_shipping","","0","0","0","2021-06-10 15:03:43");
INSERT INTO menus VALUES("134","analytics","analytics.php","115","","","0","0","0","2021-06-10 16:08:00");
INSERT INTO menus VALUES("135","sale report","sale_report.php","115","shopping_cart","","0","0","0","2023-10-02 15:23:15");
INSERT INTO menus VALUES("136","general voucher","voucher.php?act=general_voucher","101","add_to_queue","","1","0","1","2021-06-20 18:20:15");
INSERT INTO menus VALUES("137","expense voucher","voucher.php?act=expense_voucher","101","local_shipping","","1","0","1","2021-06-20 18:30:18");
INSERT INTO menus VALUES("138","single voucher","voucher.php?act=single_voucher","101","shopping_cart","","1","1","1","2021-06-20 18:30:47");
INSERT INTO menus VALUES("139","voucher lists","voucher.php?act=lists","101","shopping_cart","","1","1","1","2021-06-20 18:31:37");
INSERT INTO menus VALUES("140","backup & restore","backup.php","107","shopping_cart","","1","0","1","2021-06-26 12:56:24");
INSERT INTO menus VALUES("141","list dc","credit_orders.php","104","","","0","0","0","2023-10-02 15:22:39");
INSERT INTO menus VALUES("142","PO","#","0","","3","0","0","0","2026-10-29 17:48:34");
INSERT INTO menus VALUES("143","Add Po","purchase_order.php","142","","","1","0","1","2026-10-29 17:48:34");
INSERT INTO menus VALUES("144","Po list","purchase_order_list.php","142","","","1","1","1","2026-10-29 17:48:34");
INSERT INTO menus VALUES("145","Goods Issue","cash_sale.php?type=goodsissue","112","","","1","1","1","2023-10-09 23:34:56");
INSERT INTO menus VALUES("146","Issues List","goodsissuelist.php","112","","","1","1","1","2023-10-10 00:25:45");
INSERT INTO menus VALUES("147","","#","104","","","0","0","0","2023-10-17 00:33:23");
INSERT INTO menus VALUES("148","commercial invoice","invoice.php","104","","","0","0","1","2026-10-29 17:48:34");
INSERT INTO menus VALUES("149","commercial invoice list","invoice_list.php","104","","","1","1","1","2026-10-29 17:48:34");
INSERT INTO menus VALUES("150","Tax Invoices","#","0","","5","0","0","0","2026-10-29 16:54:55");
INSERT INTO menus VALUES("151","Tax Sale","tax_sale.php","150","","1","0","0","0","2026-10-27 11:23:21");
INSERT INTO menus VALUES("152","Tax Sale List","tax_sale_list.php","150","","2","0","0","0","2026-10-27 11:23:21");
INSERT INTO menus VALUES("153","Tax Purchase","tax_purchase.php","150","","3","0","0","0","2026-10-27 11:23:21");
INSERT INTO menus VALUES("154","Tax Purchase List","tax_purchase_list.php","150","","4","0","0","0","2026-10-27 11:23:21");
INSERT INTO menus VALUES("155","commercial invoice ledger","commercial_invoice_ledger.php","115","","7","0","0","0","2026-10-28 16:13:12");
INSERT INTO menus VALUES("156","Monthly Tax Return","monthly_tax_return.php","150","","5","0","0","0","2026-10-28 16:51:30");
INSERT INTO menus VALUES("157","Monthly Tax Return","monthly_tax_return.php","115","","20","0","0","0","2026-10-28 17:00:28");
INSERT INTO menus VALUES("158","WHT Report","wht_report.php","115","","21","1","1","1","2026-10-29 11:34:06");
INSERT INTO menus VALUES("159","Monthly WHT Report","wht_report.php","150","","6","1","1","1","2026-10-29 11:34:06");
INSERT INTO menus VALUES("160","Pending Dues (Receivables & Payables)","dues_report.php","115","","22","0","0","0","2026-10-29 11:40:35");





CREATE TABLE `order_item` (
  `order_item_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL DEFAULT 0,
  `product_id` int(11) NOT NULL DEFAULT 0,
  `quantity` double NOT NULL,
  `rate_mm` varchar(50) NOT NULL DEFAULT '0',
  `rate` double NOT NULL,
  `total` double NOT NULL,
  `order_item_status` int(11) NOT NULL DEFAULT 0,
  `pckg` varchar(10) DEFAULT NULL,
  `p_pckg` varchar(10) DEFAULT NULL,
  `width` text DEFAULT NULL,
  PRIMARY KEY (`order_item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO order_item VALUES("1","1","2","100","undefined","5000","500000","1","10","10","");
INSERT INTO order_item VALUES("4","4","1","100","undefined","5000","500000","1","10","10","");
INSERT INTO order_item VALUES("5","4","111","100","undefined","1000","100000","1","10","10","");





CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_paid_id` int(11) DEFAULT NULL,
  `order_date` date NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `client_contact` varchar(255) NOT NULL,
  `party_po` varchar(50) DEFAULT NULL,
  `sub_total` varchar(255) NOT NULL,
  `vat` varchar(255) NOT NULL,
  `total_amount` varchar(255) NOT NULL,
  `discount` varchar(255) NOT NULL,
  `cod` varchar(200) NOT NULL,
  `grand_total` varchar(255) NOT NULL,
  `paid` varchar(255) NOT NULL,
  `due` varchar(255) NOT NULL,
  `payment_type` varchar(30) NOT NULL,
  `payment_status` int(11) NOT NULL,
  `customer_account` int(11) DEFAULT NULL,
  `payment_account` int(11) DEFAULT NULL,
  `order_status` varchar(20) NOT NULL DEFAULT '0',
  `address` varchar(500) NOT NULL,
  `charges` varchar(200) NOT NULL,
  `note` varchar(1000) NOT NULL,
  `pending_order` varchar(1000) NOT NULL,
  `tracking` varchar(200) NOT NULL,
  `customer_profit` varchar(255) NOT NULL,
  `transaction_id` int(11) NOT NULL DEFAULT 0,
  `broker_id` int(11) DEFAULT NULL,
  `type` text DEFAULT NULL,
  `delaytime` text DEFAULT NULL,
  `freight` text DEFAULT NULL,
  `order_narration` text DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `credit_sale_type` varchar(20) NOT NULL DEFAULT 'none',
  `vehicle_no` varchar(100) DEFAULT NULL,
  `page_type` varchar(50) DEFAULT 'sale',
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO orders VALUES("1","0","2026-10-29","Muhammad Ahsan","435345435","34","","","500000","0","","500000","0","500000","credit_sale","0","16","3","1","","","","","","","1","","","","","test","2026-10-29 13:50:31","30days","456","sale");
INSERT INTO orders VALUES("4","0","2026-10-29","Umer Bahi AT","","12","","","600000","0","","600000","0","600000","credit_sale","0","10","6","1","","","","","","","5","","","","","","2026-10-29 15:53:28","30days","","sale");





CREATE TABLE `privileges` (
  `privileges_id` int(255) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `nav_id` int(11) NOT NULL,
  `nav_url` text NOT NULL,
  `addby` text NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `nav_add` int(11) NOT NULL DEFAULT 0,
  `nav_edit` int(11) NOT NULL DEFAULT 0,
  `nav_delete` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`privileges_id`)
) ENGINE=InnoDB AUTO_INCREMENT=468 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO privileges VALUES("332","1","98","customers.php?type=customer","Added By: admin","2021-04-15 17:26:49","1","0","1");
INSERT INTO privileges VALUES("333","1","99","customers.php?type=bank","Added By: admin","2021-04-15 17:26:49","1","0","1");
INSERT INTO privileges VALUES("334","1","100","users.php","Added By: admin","2021-04-15 17:26:49","1","0","1");
INSERT INTO privileges VALUES("335","1","102","voucher.php?act=add","Added By: admin","2021-04-15 17:26:49","1","0","0");
INSERT INTO privileges VALUES("336","1","103","voucher.php?act=list","Added By: admin","2021-04-15 17:26:49","1","0","1");
INSERT INTO privileges VALUES("337","1","105","cash_sale.php","Added By: admin","2021-04-15 17:26:49","1","0","0");
INSERT INTO privileges VALUES("338","1","106","view_orders.php","Added By: admin","2021-04-15 17:26:49","0","0","0");
INSERT INTO privileges VALUES("339","1","108","product.php?act=add#","Added By: admin","2021-04-15 17:26:49","1","0","0");
INSERT INTO privileges VALUES("340","1","109","product.php?act=list","Added By: admin","2021-04-15 17:26:49","1","0","1");
INSERT INTO privileges VALUES("341","1","110","brands.php#","Added By: admin","2021-04-15 17:26:49","1","0","1");
INSERT INTO privileges VALUES("342","1","111","credit_sale.php","Added By: admin","2021-04-15 17:26:49","1","0","0");
INSERT INTO privileges VALUES("343","1","113","cash_purchase.php","Added By: admin","2021-04-15 17:26:49","1","0","1");
INSERT INTO privileges VALUES("344","1","114","credit_purchase.php","Added By: admin","2021-04-15 17:26:49","1","0","1");
INSERT INTO privileges VALUES("345","1","116","reports.php?type=bank","Added By: admin","2021-04-15 17:26:49","1","0","1");
INSERT INTO privileges VALUES("346","1","117","reports.php?type=supplier","Added By: admin","2021-04-15 17:26:49","0","0","0");
INSERT INTO privileges VALUES("347","1","118","reports.php?type=customer ","Added By: admin","2021-04-15 17:26:49","0","0","0");
INSERT INTO privileges VALUES("348","1","119","view_purchases.php","Added By: admin","2021-04-15 17:26:49","0","0","0");
INSERT INTO privileges VALUES("349","1","0","","Added By: admin","2021-04-15 17:26:49","0","0","0");
INSERT INTO privileges VALUES("386","2","98","customers.php?type=customer","Added By: admin","2021-06-04 17:43:16","1","0","1");
INSERT INTO privileges VALUES("387","2","99","customers.php?type=bank","Added By: admin","2021-06-04 17:43:16","1","0","1");
INSERT INTO privileges VALUES("388","2","100","users.php","Added By: admin","2021-06-04 17:43:16","1","0","1");
INSERT INTO privileges VALUES("389","2","102","voucher.php?act=add","Added By: admin","2021-06-04 17:43:16","1","0","0");
INSERT INTO privileges VALUES("390","2","103","voucher.php?act=list","Added By: admin","2021-06-04 17:43:16","1","0","1");
INSERT INTO privileges VALUES("391","2","105","cash_sale.php","Added By: admin","2021-06-04 17:43:16","1","0","0");
INSERT INTO privileges VALUES("392","2","106","view_orders.php","Added By: admin","2021-06-04 17:43:16","0","0","0");
INSERT INTO privileges VALUES("393","2","108","product.php?act=add#","Added By: admin","2021-06-04 17:43:16","1","0","0");
INSERT INTO privileges VALUES("394","2","109","product.php?act=list","Added By: admin","2021-06-04 17:43:16","1","0","1");
INSERT INTO privileges VALUES("395","2","110","brands.php#","Added By: admin","2021-06-04 17:43:16","1","0","1");
INSERT INTO privileges VALUES("396","2","111","credit_sale.php?credit_type=30days","Added By: admin","2021-06-04 17:43:16","1","0","1");
INSERT INTO privileges VALUES("397","2","113","cash_purchase.php","Added By: admin","2021-06-04 17:43:16","1","0","1");
INSERT INTO privileges VALUES("398","2","114","credit_purchase.php","Added By: admin","2021-06-04 17:43:16","1","0","0");
INSERT INTO privileges VALUES("399","2","116","reports.php?type=bank","Added By: admin","2021-06-04 17:43:16","0","0","0");
INSERT INTO privileges VALUES("400","2","117","reports.php?type=supplier","Added By: admin","2021-06-04 17:43:16","0","0","1");
INSERT INTO privileges VALUES("401","2","118","reports.php?type=customer ","Added By: admin","2021-06-04 17:43:16","1","0","0");
INSERT INTO privileges VALUES("402","2","119","view_purchases.php","Added By: admin","2021-06-04 17:43:16","0","0","0");
INSERT INTO privileges VALUES("403","2","0","categories.php#","Added By: admin","2021-06-04 17:43:16","0","0","0");
INSERT INTO privileges VALUES("410","6","98","customers.php?type=customer","Added By: admin","2021-06-20 19:22:42","1","1","1");
INSERT INTO privileges VALUES("411","6","99","customers.php?type=bank","Added By: admin","2021-06-20 19:22:42","1","1","1");
INSERT INTO privileges VALUES("412","6","100","users.php","Added By: admin","2021-06-20 19:22:42","1","1","1");
INSERT INTO privileges VALUES("413","6","105","cash_sale.php","Added By: admin","2021-06-20 19:22:43","1","1","0");
INSERT INTO privileges VALUES("414","6","106","view_orders.php","Added By: admin","2021-06-20 19:22:43","0","0","0");
INSERT INTO privileges VALUES("415","6","108","product.php?act=add#","Added By: admin","2021-06-20 19:22:43","1","1","0");
INSERT INTO privileges VALUES("416","6","109","product.php?act=list","Added By: admin","2021-06-20 19:22:43","1","1","1");
INSERT INTO privileges VALUES("417","6","110","brands.php#","Added By: admin","2021-06-20 19:22:43","1","1","1");
INSERT INTO privileges VALUES("418","6","111","credit_sale.php?credit_type=15days","Added By: admin","2021-06-20 19:22:43","1","1","1");
INSERT INTO privileges VALUES("419","6","113","cash_purchase.php","Added By: admin","2021-06-20 19:22:43","1","1","1");
INSERT INTO privileges VALUES("420","6","114","credit_purchase.php","Added By: admin","2021-06-20 19:22:43","1","1","1");
INSERT INTO privileges VALUES("421","6","116","reports.php?type=bank","Added By: admin","2021-06-20 19:22:43","1","1","1");
INSERT INTO privileges VALUES("422","6","117","reports.php?type=supplier","Added By: admin","2021-06-20 19:22:43","0","1","0");
INSERT INTO privileges VALUES("423","6","118","reports.php?type=customer ","Added By: admin","2021-06-20 19:22:43","0","0","0");
INSERT INTO privileges VALUES("424","6","119","view_purchases.php","Added By: admin","2021-06-20 19:22:43","1","1","1");
INSERT INTO privileges VALUES("425","6","120","categories.php#","Added By: admin","2021-06-20 19:22:43","1","1","1");
INSERT INTO privileges VALUES("426","6","121","customers.php?type=supplier","Added By: admin","2021-06-20 19:22:43","1","1","1");
INSERT INTO privileges VALUES("427","6","122","customers.php?type=expense","Added By: admin","2021-06-20 19:22:43","1","1","1");
INSERT INTO privileges VALUES("428","6","123","product_purchase_report.php","Added By: admin","2021-06-20 19:22:44","0","0","0");
INSERT INTO privileges VALUES("429","6","125","product_sale_report.php","Added By: admin","2021-06-20 19:22:44","0","0","0");
INSERT INTO privileges VALUES("430","6","127","expence_report.php","Added By: admin","2021-06-20 19:22:44","0","0","0");
INSERT INTO privileges VALUES("431","6","128","income_report.php","Added By: admin","2021-06-20 19:22:44","0","0","0");
INSERT INTO privileges VALUES("432","6","129","profit_loss.php","Added By: admin","2021-06-20 19:22:44","0","0","0");
INSERT INTO privileges VALUES("433","6","130","profit_summary.php","Added By: admin","2021-06-20 19:22:44","0","0","0");
INSERT INTO privileges VALUES("434","6","131","trail_balance.php#","Added By: admin","2021-06-20 19:22:44","0","0","0");
INSERT INTO privileges VALUES("435","6","132","credit_sale.php?credit_type=30days","Added By: admin","2021-06-20 19:22:44","1","1","0");
INSERT INTO privileges VALUES("436","6","133","expense_type.php","Added By: admin","2021-06-20 19:22:44","0","0","0");
INSERT INTO privileges VALUES("437","6","134","analytics.php","Added By: admin","2021-06-20 19:22:44","0","0","0");
INSERT INTO privileges VALUES("438","6","135","sale_report","Added By: admin","2021-06-20 19:22:44","0","0","0");
INSERT INTO privileges VALUES("439","6","136","voucher.php?act=general_voucher","Added By: admin","2021-06-20 19:22:44","1","1","0");
INSERT INTO privileges VALUES("440","6","137","voucher.php?act=expense_voucher","Added By: admin","2021-06-20 19:22:44","1","1","0");
INSERT INTO privileges VALUES("441","6","138","voucher.php?act=single_voucher","Added By: admin","2021-06-20 19:22:44","1","1","1");
INSERT INTO privileges VALUES("442","6","139","voucher.php?act=lists","Added By: admin","2021-06-20 19:22:44","1","1","1");
INSERT INTO privileges VALUES("443","6","0","","Added By: admin","2021-06-20 19:22:44","0","0","0");
INSERT INTO privileges VALUES("444","1","151","tax_sale.php","Added By: admin","2026-10-27 11:23:21","1","1","1");
INSERT INTO privileges VALUES("445","2","151","tax_sale.php","Added By: admin","2026-10-27 11:23:21","1","1","1");
INSERT INTO privileges VALUES("446","1","152","tax_sale_list.php","Added By: admin","2026-10-27 11:23:21","1","1","1");
INSERT INTO privileges VALUES("447","2","152","tax_sale_list.php","Added By: admin","2026-10-27 11:23:21","1","1","1");
INSERT INTO privileges VALUES("448","1","153","tax_purchase.php","Added By: admin","2026-10-27 11:23:21","1","1","1");
INSERT INTO privileges VALUES("449","2","153","tax_purchase.php","Added By: admin","2026-10-27 11:23:21","1","1","1");
INSERT INTO privileges VALUES("450","1","154","tax_purchase_list.php","Added By: admin","2026-10-27 11:23:21","1","1","1");
INSERT INTO privileges VALUES("451","2","154","tax_purchase_list.php","Added By: admin","2026-10-27 11:23:21","1","1","1");
INSERT INTO privileges VALUES("459","1","155","","","2026-10-28 16:13:12","1","1","1");
INSERT INTO privileges VALUES("460","2","155","","","2026-10-28 16:13:12","1","1","1");
INSERT INTO privileges VALUES("461","1","156","","","2026-10-28 16:51:30","0","0","0");
INSERT INTO privileges VALUES("462","2","156","","","2026-10-28 16:51:30","0","0","0");
INSERT INTO privileges VALUES("463","1","156","","","2026-10-28 16:51:30","0","0","0");
INSERT INTO privileges VALUES("464","1","157","","","2026-10-28 17:00:28","0","0","0");
INSERT INTO privileges VALUES("465","2","158","wht_report.php","admin","2026-10-29 11:34:06","1","1","1");
INSERT INTO privileges VALUES("466","2","159","wht_report.php","admin","2026-10-29 11:34:06","1","1","1");
INSERT INTO privileges VALUES("467","1","160","dues_report.php","","2026-10-29 11:40:35","1","1","1");





CREATE TABLE `product` (
  `product_id` int(200) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL,
  `product_name2` varchar(50) DEFAULT NULL,
  `product_code` varchar(250) DEFAULT NULL,
  `hs_code` varchar(255) DEFAULT NULL,
  `product_image` text NOT NULL,
  `brand_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `quantity_instock` double NOT NULL,
  `hold_product` int(100) DEFAULT NULL,
  `purchased` double NOT NULL,
  `current_rate` double NOT NULL,
  `f_days` text DEFAULT NULL,
  `t_days` text DEFAULT NULL,
  `purchase_rate` double NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `availability` int(11) DEFAULT 0,
  `alert_at` double DEFAULT 5,
  `weight` varchar(200) NOT NULL,
  `actual_rate` varchar(250) DEFAULT NULL,
  `product_description` text DEFAULT NULL,
  `product_mm` varchar(100) NOT NULL DEFAULT '0',
  `product_inch` varchar(100) NOT NULL DEFAULT '0',
  `product_meter` varchar(100) NOT NULL DEFAULT '0',
  `product_unit` varchar(100) DEFAULT NULL,
  `adddatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `inventory` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO product VALUES("1","b2 10x50x24","","b2105024","40440","","1","1","-2137","","0","4900","4920","4970","4800","1","1","5","","","b2 10x50x24","","","","meter","2026-10-29 15:53:28","0");
INSERT INTO product VALUES("2","b2 10x54x24","","b2105424","","","1","1","-945","","0","5000","5050","5100","4960","1","1","5","","","b2 10x54x24","0","0","0","","2026-10-29 13:40:08","0");
INSERT INTO product VALUES("3","b2 10x60x26","","b2106026","","","1","1","-1468","","0","5450","5470","5526","0","1","1","5","","","b2 10x60x26","0","0","0","","2026-10-29 14:05:23","0");
INSERT INTO product VALUES("4","b2 12x50x24","","b2125024","","","1","1","-14300","","0","5150","5170","5250","5000","1","1","5","","","b2 12x50x24","","","","yard","2026-10-26 16:44:44","0");
INSERT INTO product VALUES("5","b2 12x54x24","","b2125424","","","1","1","9","","0","5350","5380","5440","0","0","1","5","","","b2 12x54x24","0","0","0","","2026-10-24 13:35:26","0");
INSERT INTO product VALUES("6","b2 12x60x24","","b2126024","","","1","1","0","","0","5900","5930","5990","0","0","1","5","","","\nb2 12x60x24","0","0","0","","2026-10-24 12:51:33","0");
INSERT INTO product VALUES("7","b2 14x50x24","","b2145024","","","1","1","0","","0","5575","5600","5650","0","0","1","5","","","b2 14x50x24","0","0","0","","2026-10-24 12:51:21","0");
INSERT INTO product VALUES("8","b2 14x54x24","","b2145424","456","","1","1","0","","0","5800","5820","5870","5000","0","1","5","","","b2 14x54x24","","","","yard","2026-10-24 12:20:31","0");
INSERT INTO product VALUES("9","b2 14x60x24","","b2146024","","","1","1","0","","0","6350","6370","6500","0","0","1","5","","","b2 14x60x24","0","0","0","","2026-10-24 12:18:59","0");
INSERT INTO product VALUES("111","ZIPPER","","240808","9607.1900","","10","14","3500","","1000","0.5","0.5","0.5","780","1","1","5","1","","zip#5 (3.1kg) white","","","","yards","2026-10-29 15:53:28","0");
INSERT INTO product VALUES("112","testing","","SF1002788","9607.1901","","1","4","0","","0","300","300","300","250","1","1","5","","","","333","555","555","","2026-10-28 13:01:47","0");
INSERT INTO product VALUES("113","testing","","SF1000001","9607.1901","","1","2","0","","0","300","300","300","200","1","1","5","","","","234","456","567","","2026-10-28 13:04:13","0");





CREATE TABLE `purchase` (
  `purchase_id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_date` date NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `client_contact` varchar(255) NOT NULL,
  `sub_total` varchar(255) NOT NULL,
  `vat` varchar(255) NOT NULL,
  `total_amount` varchar(255) NOT NULL,
  `discount` varchar(255) NOT NULL,
  `freight` varchar(50) DEFAULT NULL,
  `grand_total` varchar(255) NOT NULL,
  `paid` varchar(255) NOT NULL,
  `due` varchar(255) NOT NULL,
  `payment_type` varchar(30) DEFAULT NULL,
  `payment_account` int(11) DEFAULT NULL,
  `customer_account` int(11) DEFAULT NULL,
  `payment_status` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `transaction_paid_id` int(11) NOT NULL,
  `purchase_narration` text DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`purchase_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;






CREATE TABLE `purchase_item` (
  `purchase_item_id` int(255) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(255) NOT NULL,
  `product_id` int(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `rate_mm` varchar(50) NOT NULL DEFAULT '0',
  `rate` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `purchase_item_status` int(11) NOT NULL,
  PRIMARY KEY (`purchase_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;






CREATE TABLE `purchase_order` (
  `po_id` int(255) NOT NULL AUTO_INCREMENT,
  `po_date` varchar(50) NOT NULL,
  `po_customer` int(10) NOT NULL,
  `po_customer_name` varchar(50) DEFAULT NULL,
  `po_customer_no` varchar(50) DEFAULT NULL,
  `po_partystm` varchar(50) NOT NULL,
  `po_partypo` varchar(50) NOT NULL,
  `po_remarks` text NOT NULL,
  `po_paymentdays` varchar(10) NOT NULL,
  `po_targetdate` varchar(50) NOT NULL,
  `po_consumer` text NOT NULL,
  `po_jobdesc` text NOT NULL,
  `user_id` int(10) NOT NULL,
  `discount` varchar(50) DEFAULT '0',
  `freight` varchar(50) DEFAULT '0',
  `grand_total` varchar(50) NOT NULL,
  `add_datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`po_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO purchase_order VALUES("1","2026-10-29","10","Umer Bahi AT","","","12","testings","30","2026-11-05","","","0","18","","708000","2026-10-29 12:57:15");
INSERT INTO purchase_order VALUES("2","2026-10-26","16","Muhammad Ahsan","435345435","","34","second test","45","2026-11-03","","","0","18","","590000","2026-10-29 12:58:34");
INSERT INTO purchase_order VALUES("3","2026-10-28","10","Umer Bahi AT","","","45","teeee","60","2026-11-02","","","0","18","","590000","2026-10-29 13:00:01");





CREATE TABLE `purchase_order_item` (
  `po_item_id` int(255) NOT NULL AUTO_INCREMENT,
  `po_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` double NOT NULL,
  `rate` double NOT NULL,
  `total` double NOT NULL,
  `add_datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`po_item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO purchase_order_item VALUES("1","1","111","100","1000","100000","2026-10-29 12:57:15");
INSERT INTO purchase_order_item VALUES("2","1","1","100","5000","500000","2026-10-29 12:57:15");
INSERT INTO purchase_order_item VALUES("3","2","2","100","5000","500000","2026-10-29 12:58:34");
INSERT INTO purchase_order_item VALUES("4","3","3","100","5000","500000","2026-10-29 13:00:01");





CREATE TABLE `tax_purchase_items` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_purchase_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `description_of_goods` varchar(255) NOT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `hs_code` varchar(100) DEFAULT NULL,
  `origin` varchar(100) DEFAULT NULL,
  `quantity` decimal(15,3) NOT NULL DEFAULT 0.000,
  `rate` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `value_excl_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `tax_rate` decimal(5,2) NOT NULL DEFAULT 18.00,
  `tax_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `further_tax_rate` decimal(5,2) NOT NULL DEFAULT 0.00,
  `further_tax_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total_tax_payable` decimal(15,2) NOT NULL DEFAULT 0.00,
  `value_incl_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`item_id`),
  KEY `tax_purchase_id` (`tax_purchase_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;






CREATE TABLE `tax_purchases` (
  `tax_purchase_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(100) NOT NULL,
  `invoice_date` date NOT NULL,
  `tax_month` varchar(20) DEFAULT NULL,
  `time_of_supply` varchar(100) DEFAULT NULL,
  `payment_terms` varchar(100) DEFAULT 'CREDIT',
  `copy_type` varchar(50) DEFAULT 'ORIGINAL',
  `supplier_id` int(11) DEFAULT NULL,
  `company_id` int(11) DEFAULT 5,
  `transaction_id` int(11) DEFAULT NULL,
  `header_description` text DEFAULT NULL,
  `gd_number` varchar(100) DEFAULT NULL,
  `total_qty` decimal(15,3) DEFAULT 0.000,
  `total_value_excl_tax` decimal(15,2) DEFAULT 0.00,
  `total_sales_tax` decimal(15,2) DEFAULT 0.00,
  `total_further_tax` decimal(15,2) DEFAULT 0.00,
  `total_tax_payable` decimal(15,2) DEFAULT 0.00,
  `total_value_incl_tax` decimal(15,2) DEFAULT 0.00,
  `itax_236g_rate` decimal(5,2) DEFAULT 0.10,
  `itax_236g_amount` decimal(15,2) DEFAULT 0.00,
  `invoice_amount` decimal(15,2) DEFAULT 0.00,
  `amount_in_words` text DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`tax_purchase_id`),
  KEY `invoice_no` (`invoice_no`),
  KEY `supplier_id` (`supplier_id`),
  KEY `invoice_date` (`invoice_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;






CREATE TABLE `tax_return_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entry_date` date NOT NULL,
  `tax_month` varchar(20) NOT NULL,
  `transaction_type` enum('Purchase','Sale') NOT NULL,
  `po_no` varchar(100) DEFAULT '',
  `party_name` varchar(255) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `invoice_no` varchar(100) DEFAULT '',
  `item_name` varchar(255) NOT NULL DEFAULT 'ZIPPER',
  `kg` decimal(15,3) NOT NULL DEFAULT 0.000,
  `rate_excl_tax` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `taxable_value` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `gst_rate` decimal(5,2) NOT NULL DEFAULT 18.00,
  `gst_amount` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `invoice_total` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `running_stock_kg` decimal(15,4) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `tax_purchase_id` int(11) DEFAULT NULL,
  `tax_sale_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `entry_date` (`entry_date`),
  KEY `tax_month` (`tax_month`),
  KEY `transaction_type` (`transaction_type`),
  KEY `po_no` (`po_no`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;






CREATE TABLE `tax_sale_items` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_sale_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `description_of_goods` varchar(255) NOT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `hs_code` varchar(100) DEFAULT NULL,
  `origin` varchar(100) DEFAULT NULL,
  `quantity` decimal(15,3) NOT NULL DEFAULT 0.000,
  `rate` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `value_excl_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `tax_rate` decimal(5,2) NOT NULL DEFAULT 18.00,
  `tax_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `further_tax_rate` decimal(5,2) DEFAULT 0.00,
  `further_tax_amount` decimal(15,2) DEFAULT 0.00,
  `total_tax_payable` decimal(15,2) DEFAULT 0.00,
  `value_incl_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`item_id`),
  KEY `tax_sale_id` (`tax_sale_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tax_sale_items VALUES("4","4","2","b2 10x54x24","KG","","","100.000","5000.0000","500000.00","18.00","90000.00","0.00","0.00","90000.00","590000.00");





CREATE TABLE `tax_sales` (
  `tax_sale_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(100) NOT NULL,
  `invoice_date` date NOT NULL,
  `tax_month` varchar(20) DEFAULT NULL,
  `time_of_supply` varchar(100) DEFAULT NULL,
  `payment_terms` varchar(100) DEFAULT 'CREDIT',
  `copy_type` varchar(50) DEFAULT 'ORIGINAL',
  `po_no` varchar(100) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `company_id` int(11) DEFAULT 5,
  `transaction_id` int(11) DEFAULT 0,
  `header_description` text DEFAULT NULL,
  `total_qty` decimal(15,3) DEFAULT 0.000,
  `total_value_excl_tax` decimal(15,2) DEFAULT 0.00,
  `total_sales_tax` decimal(15,2) DEFAULT 0.00,
  `total_further_tax` decimal(15,2) DEFAULT 0.00,
  `total_tax_payable` decimal(15,2) DEFAULT 0.00,
  `total_value_incl_tax` decimal(15,2) DEFAULT 0.00,
  `itax_236g_rate` decimal(5,2) DEFAULT 0.10,
  `itax_236g_amount` decimal(15,2) DEFAULT 0.00,
  `total_tax_amount` decimal(15,2) DEFAULT 0.00,
  `grand_total` decimal(15,2) DEFAULT 0.00,
  `amount_in_words` text DEFAULT NULL,
  `fbr_invoice_no` varchar(100) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`tax_sale_id`),
  KEY `invoice_no` (`invoice_no`),
  KEY `customer_id` (`customer_id`),
  KEY `invoice_date` (`invoice_date`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tax_sales VALUES("4","4","2026-10-29","","","CREDIT","ORIGINAL","34","16","5","8","GST Invoice Number : 4 / BA TRADERS / P.O # : 34","100.000","500000.00","90000.00","0.00","90000.00","590000.00","0.10","0.00","90000.00","590000.00","RUPEES: FIVE HUNDRED NINETY THOUSAND ONLY.","","","1","2026-10-29 17:54:54");





CREATE TABLE `transactions` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `debit` varchar(100) NOT NULL,
  `credit` varchar(100) NOT NULL,
  `balance` varchar(100) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `transaction_remarks` text NOT NULL,
  `transaction_add_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `transaction_date` text DEFAULT NULL,
  `transaction_type` text DEFAULT NULL,
  `transaction_from` text DEFAULT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO transactions VALUES("8","0","590000","","16","Sales Tax Invoice #4","2026-10-29 17:54:54","2026-10-29","credit_sale","invoice");





CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `fullname` varchar(50) DEFAULT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `address` text NOT NULL,
  `phone` text NOT NULL,
  `user_role` text NOT NULL,
  `status` text NOT NULL,
  `cash_account` int(10) DEFAULT NULL,
  `adddatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO users VALUES("1","admin","admin","adminn@gmail.com","21232f297a57a5a743894a0e4a801fc3","asergh","2345y","admin","1","","2021-06-21 16:16:04");
INSERT INTO users VALUES("2","sami","","sami@gmail.com","d54d1702ad0f8326224b817c796763c9","main bazar sadhar faisalabad","12345","subadmin","1","6","2023-09-25 15:21:40");





CREATE TABLE `voucher_invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_id` int(11) NOT NULL,
  `invoice_id` varchar(100) NOT NULL,
  `party_po` varchar(100) DEFAULT NULL,
  `invoice_amount` varchar(100) DEFAULT '0',
  `tax_percent` varchar(50) DEFAULT '5.5',
  `tax_amount` varchar(100) DEFAULT '0',
  `received_amount` varchar(100) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `voucher_id` (`voucher_id`),
  KEY `invoice_id` (`invoice_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;






CREATE TABLE `vouchers` (
  `voucher_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id1` varchar(250) DEFAULT NULL,
  `customer_id2` varchar(250) DEFAULT NULL,
  `addby_user_id` int(11) DEFAULT NULL,
  `editby_user_id` int(11) DEFAULT NULL,
  `voucher_amount` varchar(250) NOT NULL,
  `transaction_id1` varchar(250) DEFAULT NULL,
  `transaction_id2` varchar(250) DEFAULT NULL,
  `voucher_hint` text DEFAULT NULL,
  `voucher_date` varchar(100) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `voucher_type` varchar(100) DEFAULT NULL,
  `voucher_group` varchar(100) DEFAULT NULL,
  `td_check_no` text DEFAULT NULL,
  `voucher_bank_name` varchar(255) DEFAULT NULL,
  `td_check_date` varchar(100) DEFAULT NULL,
  `check_type` varchar(150) DEFAULT NULL,
  `voucher_details` text DEFAULT NULL,
  PRIMARY KEY (`voucher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;




